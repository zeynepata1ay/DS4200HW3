// Load the data from the CSV file
d3.csv("socialMedia.csv").then(function(data) {
  // Convert 'Likes' column values to numbers for proper numerical calculations
  data.forEach(d => {
      d.Likes = +d.Likes;
  });

  // Define SVG dimensions and margins
  const margin = { top: 20, right: 30, bottom: 40, left: 50 };
  const width = 600 - margin.left - margin.right;
  const height = 400 - margin.top - margin.bottom;

  // Create the SVG container and append it to the 'boxplot' div
  const svg = d3.select("#boxplot")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

  // Define scales for x and y axes
  const xScale = d3.scaleBand()
      .domain([...new Set(data.map(d => d.Platform))]) // Extract unique platform names
      .range([0, width])
      .padding(0.5);

  const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.Likes)]) // Scale based on the range of Likes
      .nice()
      .range([height, 0]);

  // Add x and y axes
  svg.append("g")
      .attr("transform", `translate(0, ${height})`)
      .call(d3.axisBottom(xScale));

  svg.append("g")
      .call(d3.axisLeft(yScale));

  // Define a function to calculate quartiles for each platform
  const rollupFunction = function(groupData) {
      const values = groupData.map(d => d.Likes).sort(d3.ascending);
      const min = d3.min(values);
      const q1 = d3.quantile(values, 0.25); // First quartile (25th percentile)
      const median = d3.quantile(values, 0.5); // Median (50th percentile)
      const q3 = d3.quantile(values, 0.75); // Third quartile (75th percentile)
      const max = d3.max(values);
      return { min, q1, median, q3, max };
  };

// Group the data by 'Platform' and compute quartiles for each platform.
// 'd3.rollup()' creates a Map where each key is a unique platform (e.g., Facebook, Twitter),
// and the value is an object containing the quartiles (min, Q1, median, Q3, max) for the 'Likes' variable.
const quartilesByPlatform = d3.rollup(data, rollupFunction, d => d.Platform);

// Iterate over each platform to draw its respective box plot components.
// 'platform' represents the current social media platform (e.g., Facebook, Twitter),
// and 'quartiles' contains the computed quartile values (min, Q1, median, Q3, max).
// 'xScale(platform)' determines the x-axis position of each box plot,
// and 'xScale.bandwidth()' specifies the width of the box for each platform.
quartilesByPlatform.forEach((quartiles, platform) => {
      const x = xScale(platform);
      const boxWidth = xScale.bandwidth();

      // Draw the vertical line (whisker) from min to max values
      svg.append("line")
          .attr("x1", x + boxWidth / 2)
          .attr("x2", x + boxWidth / 2)
          .attr("y1", yScale(quartiles.min))
          .attr("y2", yScale(quartiles.max))
          .attr("stroke", "black");

      // Draw the rectangular box representing Q1 to Q3 range
      svg.append("rect")
          .attr("x", x)
          .attr("y", yScale(quartiles.q3))
          .attr("width", boxWidth)
          .attr("height", yScale(quartiles.q1) - yScale(quartiles.q3))
          .attr("fill", "lightblue")
          .attr("stroke", "black");

      // Draw the horizontal line for the median inside the box
      svg.append("line")
          .attr("x1", x)
          .attr("x2", x + boxWidth)
          .attr("y1", yScale(quartiles.median))
          .attr("y2", yScale(quartiles.median))
          .attr("stroke", "black");
  });

});

// ---------------------------------------------------------------------------------------------------------

// Load the summarized data containing Platform, PostType, and AvgLikes
d3.csv("socialMediaAvg.csv").then(function(data) {
  // Convert 'AvgLikes' column to numeric values
  data.forEach(d => {
      d.AvgLikes = +d.AvgLikes;
  });

  // Define SVG dimensions and margins
  const margin = { top: 30, right: 100, bottom: 60, left: 50 };
  const width = 700 - margin.left - margin.right;
  const height = 400 - margin.top - margin.bottom;

  // Create the SVG container and append it to the 'barplot' div
  const svg = d3.select("#barplot")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

  // Define scales
  // x0: Scale for Platform (main categories)
  const x0 = d3.scaleBand()
      .domain([...new Set(data.map(d => d.Platform))]) // Unique platforms
      .range([0, width])
      .padding(0.2);

  // x1: Scale for PostType (subcategories within each platform)
  const x1 = d3.scaleBand()
      .domain([...new Set(data.map(d => d.PostType))]) // Unique post types
      .range([0, x0.bandwidth()])
      .padding(0.1);

  // y: Scale for AvgLikes (numerical scale)
  const y = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.AvgLikes)])
      .nice()
      .range([height, 0]);

  // Color scale for PostType
  const color = d3.scaleOrdinal()
      .domain([...new Set(data.map(d => d.PostType))])
      .range(["#1f77b4", "#ff7f0e", "#2ca02c"]);    

  // Add axes
  svg.append("g")
      .attr("transform", `translate(0, ${height})`)
      .call(d3.axisBottom(x0));

  svg.append("g")
      .call(d3.axisLeft(y));

  // Group the data by Platform and create bar groups
  const barGroups = svg.selectAll(".bar-group")
      .data(data)
      .enter()
      .append("g")
      .attr("transform", d => `translate(${x0(d.Platform)},0)`);

  // Draw bars for each PostType inside the respective platform group
  barGroups.append("rect")
      .attr("x", d => x1(d.PostType))
      .attr("y", d => y(d.AvgLikes))
      .attr("width", x1.bandwidth())
      .attr("height", d => height - y(d.AvgLikes))
      .attr("fill", d => color(d.PostType));

  // Add the legend
  const legend = svg.append("g")
  .attr("transform", `translate(${width + 30}, ${margin.top + 20})`);

  const types = [...new Set(data.map(d => d.PostType))];

  types.forEach((type, i) => {
    // Add color box
    legend.append("rect")
        .attr("x", 0)
        .attr("y", i * 25) // Increase spacing between legend items
        .attr("width", 15)
        .attr("height", 15)
        .attr("fill", color(type));

    // Add text label next to the color box with better spacing
    legend.append("text")
        .attr("x", 25) // Move text further right
        .attr("y", i * 25 + 12) // Align text properly with the colored box
        .text(type)
        .style("font-size", "14px") // Adjust text size
        .style("font-weight", "bold")
        .attr("alignment-baseline", "middle");
});

});

// ---------------------------------------------------------------------------------------------------------

// Load the summarized data containing Date and AvgLikes
d3.csv("socialMediaTime.csv").then(function(data) {
  const parseDate = d3.timeParse("%m/%d/%Y"); // Correct date format

  data.forEach(d => {
      d.AvgLikes = +d.AvgLikes;
      d.Date = parseDate(d.Date.split(" ")[0]); // Extract only the date part (e.g., "3/1/2024")
  });  

  // Define SVG dimensions and margins
  const margin = { top: 30, right: 50, bottom: 60, left: 50 };
  const width = 700 - margin.left - margin.right;
  const height = 400 - margin.top - margin.bottom;

  // Create the SVG container and append it to the 'lineplot' div
  const svg = d3.select("#lineplot")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

  // Set up scales for x (Date) and y (AvgLikes)
  const xScale = d3.scaleTime()
      .domain(d3.extent(data, d => d.Date))
      .range([0, width]);

  const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.AvgLikes)])
      .nice()
      .range([height, 0]);

  // Add x and y axes
  svg.append("g")
      .attr("transform", `translate(0, ${height})`)
      .call(d3.axisBottom(xScale).tickFormat(d3.timeFormat("%m/%d")))
      .selectAll("text")
      .style("text-anchor", "end")
      .attr("transform", "rotate(-25)");

  svg.append("g")
      .call(d3.axisLeft(yScale));

  // Add x-axis and y-axis labels
  svg.append("text")
      .attr("x", width / 2)
      .attr("y", height + 50)
      .style("text-anchor", "middle")
      .text("Date");

  svg.append("text")
      .attr("transform", "rotate(-90)")
      .attr("x", -height / 2)
      .attr("y", -40)
      .style("text-anchor", "middle")
      .text("Average Likes");

  // Draw the line using 'curveNatural' for smooth curves
  const line = d3.line()
      .x(d => xScale(d.Date))
      .y(d => yScale(d.AvgLikes))
      .curve(d3.curveNatural);

  svg.append("path")
      .datum(data)
      .attr("fill", "none")
      .attr("stroke", "blue")
      .attr("stroke-width", 2)
      .attr("d", line);
});