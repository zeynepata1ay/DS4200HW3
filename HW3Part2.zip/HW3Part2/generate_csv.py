import pandas as pd

# Load the social media dataset
df = pd.read_csv("socialMedia.csv")

# Convert 'Likes' column to numeric (in case of missing or incorrect values)
df['Likes'] = pd.to_numeric(df['Likes'], errors='coerce')

# Drop any rows with missing values
df = df.dropna(subset=['Likes', 'Platform', 'PostType', 'Date'])

# Generate socialMediaAvg.csv (Average Likes by Platform & PostType)
df_avg = df.groupby(['Platform', 'PostType'], as_index=False)['Likes'].mean()
df_avg.rename(columns={'Likes': 'AvgLikes'}, inplace=True)

# Round 'AvgLikes' to 2 decimal places
df_avg['AvgLikes'] = df_avg['AvgLikes'].round(2)

# Generate socialMediaTime.csv (Average Likes by Date)
df_time = df.groupby(['Date'], as_index=False)['Likes'].mean()
df_time.rename(columns={'Likes': 'AvgLikes'}, inplace=True)

# Save both files
df_avg.to_csv("socialMediaAvg.csv", index=False)
df_time.to_csv("socialMediaTime.csv", index=False)

print("CSV files generated successfully!")
print("- socialMediaAvg.csv (Average Likes per Platform & PostType)")
print("- socialMediaTime.csv (Average Likes per Date)")
